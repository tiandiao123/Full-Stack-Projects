import os

class Movie():
	def __init__(self,movie_title,poster_url,trailer_youtube):
		self.title = movie_title
		self.poster_image_url = poster_url
		self.trailer_youtube_url = trailer_youtube
