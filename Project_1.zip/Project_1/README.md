# Project Member: Cuiqing Li
# Time: Dec. 2018

### Project Description:
In this project, we need to use Python programming language to create a website for showing movie trailer! If you
click the moview poster on the webiste, and then it will show the youtube trailer on the screeen! 

### Test:
Just type 'python entertainment_center.py' on the terminal.

### Review of The Website:
![png](movie_website.PNG)

